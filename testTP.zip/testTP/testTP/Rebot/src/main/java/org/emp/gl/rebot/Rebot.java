/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.rebot;

import java.awt.event.KeyEvent;
import org.emp.gl.module1.time;
/**
 *
 * @author amell
 */
public class Rebot extends time{
    String orientation= "Up";
public void keyPressed (KeyEvent e) {
        int c = e.getKeyCode ();
        if (c==KeyEvent.VK_UP) {                
           orientation="Up";    
        } else if(c==KeyEvent.VK_DOWN) {                
               orientation="Down";
        } else if(c==KeyEvent.VK_LEFT) {                
               orientation="Left";
        } else if(c==KeyEvent.VK_RIGHT) {                
               orientation="Right";
        }
       
    }
   
} 
