
import java.awt.event.KeyEvent;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author amell
 */
public class clavier {

    public void keyPressed (KeyEvent e) {
        int c = e.getKeyCode ();
        if (c==KeyEvent.VK_UP) {                
               
        } else if(c==KeyEvent.VK_DOWN) {                
               
        } else if(c==KeyEvent.VK_LEFT) {                
               
        } else if(c==KeyEvent.VK_RIGHT) {                
               
        }
       
    }
}
