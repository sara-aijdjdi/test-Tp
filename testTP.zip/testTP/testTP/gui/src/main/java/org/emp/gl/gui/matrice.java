/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.gui;

/**
 *
 * @author amell
 */
public interface matrice {
 int[][] matrice=new int[5][5];

    /**
     *
     * @return
     */
    public int[][] getMatrice() {
        return matrice;
    }
 
    public matrice() {
        int i, j;
        for(i=0; i<matrice.length; i++){
            for(j=0; j<matrice.length ; j++){
                matrice[i][j]= (int) Math.round(Math.random());
            }
        }
    }
 
   // methode affichage
    public void afficher() {
        int i, j;
        for(i=0; i<matrice.length; i++){
            for(j=0; j<matrice.length ; j++){
                System.out.print(matrice[i][j]);
            }
            System.out.println("");
        }
    }   
}
