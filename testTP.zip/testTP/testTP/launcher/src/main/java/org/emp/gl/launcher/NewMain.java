/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.launcher;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import org.emp.gl.gui.mat;

/**
 *
 * @author amell
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
         //Add consoleLogger as a listner 
        Lookup.getLookup().addListener(new Rebot());
        //ServiceA implements Lookup.ServiceInfo (getServiceName() and  ...)
        Lookup.getLookup().register(TimerService.class, new time());
        //ServiceB does'nt implemtn Lookup.ServiceInfo 
        

        ArrayList<TimerService> list = Lookup.getLookup().getAllServices(TimerService.class);

        list.get(0).getServiceName();
        
        list.get(0).doSomething();
        
        
    }
    
}
