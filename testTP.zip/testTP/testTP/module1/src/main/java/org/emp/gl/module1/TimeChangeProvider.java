/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.module1;

/**
 *
 * @author tina
 */
public interface TimeChangeProvider {

    /**
     *
     * @param pl
     */
    public void addTimeChangeListener(TimerChangeListener pl);

    public void removeTimeChangeListener(TimerChangeListener pl);
}
