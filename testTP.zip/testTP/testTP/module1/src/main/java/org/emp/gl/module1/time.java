/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.module1;
import java.beans.PropertyChangeSupport;
import java.time.LocalTime;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author amell
 */
public  class time extends TimerTask implements TimerService{
  int dixiemeDeSeconde;
    int minutes;
    int secondes;
    int heures;
    
    PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this) ;
    
 
       public time(){
         Timer timer = new Timer();

        LocalTime localTime = LocalTime.now();
        //LocalTime localTime = LocalTime.of(15, 10, 10); pour changer 

        secondes = localTime.getSecond();
        minutes = localTime.getMinute();
        heures = localTime.getHour();
        dixiemeDeSeconde = localTime.getNano() / 100000000;

      //  timer.scheduleAtFixedRate(this, 100, 100);
    
    }
    
    
   
 
  
    public void updateSecode() {
        int oldValue = secondes;
        secondes = (secondes + 1) % 60;

        propertyChangeSupport.firePropertyChange(TimerChangeListener.SECONDE_PROP,
            oldValue, secondes);
        
       
    }
      
    private void timeChanged() {
        updateSecode();
    }





    public void onPause() throws InterruptedException{
        
        propertyChangeSupport.wait();
       
    }  
/*
    @Override
    public void run() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
*/
    @Override
    public int getSecondes() {
          return secondes;
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void addTimeChangeListener(TimerChangeListener pl) {
        propertyChangeSupport.addPropertyChangeListener(pl);
        
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeTimeChangeListener(TimerChangeListener pl) {
        
          propertyChangeSupport.removePropertyChangeListener(pl);
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void run() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
